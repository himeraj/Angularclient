import { Department } from "./department";

export class Employee {
    public id: number;
    public firstName: string;
    public departmentId: number;
    public isEdit : false;
}
