import { Employee } from "./employee";

export class Department {
    public departmentId: number;
    public departmentName: string;
}
