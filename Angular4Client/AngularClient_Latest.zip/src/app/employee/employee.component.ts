import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { DataService } from '../data.service';
import { Department } from 'app/department';

@Component({
  selector: 'customers-list',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],
})

export class EmployeeComponent implements OnInit {
  employees: Employee[];
  
  editRowId : any;
  employeeName : string;
  departmentName : string;

  constructor(private dataService: DataService) {
    this.editRowId = 0;
  }

  getEmployees() {
     this.dataService.getEmployees().then(employees => this.employees = employees);
  }

  edit(emp) {
    this.editRowId = emp.employeeId;
  }

  save(emp) {
    this.editRowId = 0;
  }

  delete(emp) {
    this.dataService.deleteEmployee(emp.id);
  }

  ngOnInit(): void {
     this.getEmployees();
  }
}